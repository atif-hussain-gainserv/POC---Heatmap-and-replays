window.addEventListener("DOMContentLoaded", function () {
  let interactions = [];
  let replayInterval;

  const record = document.getElementById("record");
  const pause = document.getElementById("pause");
  // record when record button click event
  // functions to handle the event listeners
  function handleMouseMove(event) {
    console.log("interaction recorded");
    console.log(interactions);
    interactions.push({
      type: "mousemove",
      x: event.clientX,
      y: event.clientY,
      time: Date.now(),
    });
  }

  function handleKeyPress(e) {
    console.log("interaction recorded");
    console.log(interactions);
    var action = {
      type: "keypress",
      key: e.key,
      time: Date.now(),
    };
    interactions.push(action);
  }

  // add event listeners
  record.addEventListener("click", function (e) {
    record.innerHTML = "Recording...";
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("keypress", handleKeyPress);
  });

  // remove event listeners
  pause.addEventListener("click", function (e) {
    record.innerHTML = "Record";
    document.removeEventListener("mousemove", handleMouseMove);
    document.removeEventListener("keypress", handleKeyPress);
  });

  // replay recorded actions
  function playInteractions() {
    let canvas = document.createElement("canvas");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    canvas.style.position = "fixed";
    canvas.style.top = "0";
    canvas.style.left = "0";
    canvas.style.pointerEvents = "none";
    document.body.appendChild(canvas);

    let ctx = canvas.getContext("2d");
    ctx.strokeStyle = "red";
    ctx.lineWidth = 5;

    let i = 0;
    let startTime = interactions[0].time;

    function playInteraction() {
      let interaction = interactions[i];
      if (interaction.type === "click") {
        let click = document.createElement("div");
        click.classList.add("click");
        click.style.top = interaction.y - 10 + "px";
        click.style.left = interaction.x - 10 + "px";
        document.body.appendChild(click);
      } else if (interaction.type === "mousemove") {
        ctx.beginPath();
        ctx.moveTo(interaction.x, interaction.y);
        i++;
        while (
          i < interactions.length &&
          interactions[i].type === "mousemove"
        ) {
          interaction = interactions[i];
          ctx.lineTo(interaction.x, interaction.y);
          i++;
        }
        ctx.stroke();
      }
      i++;
      if (i < interactions.length) {
        let nextInteraction = interactions[i];
        let delay = nextInteraction.time - interaction.time;
        console.log("delay --->", delay * 1000);
        setTimeout(playInteraction, delay * 1000);
      }
    }
    playInteraction();
  }

  // play recorded actions
  document.getElementById("play").addEventListener("click", function () {
    playInteractions();
  });

  // prevent default link behavior
  // document
  //   .getElementById("prevent-link")
  //   .addEventListener("click", function (e) {
  //     e.preventDefault();
  //     e.stopImmediatePropagation();
  //   });
});
