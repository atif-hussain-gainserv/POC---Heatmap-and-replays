console.log("script is linked");
const url = "http://localhost:4000/graphql";

async function getPage() {
  const foundPageData = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      query: `
      {
        page(id:"ec58c290-9684-40ec-86c3-fc135e6cdee7"){
            id
            title
            doc
            url
            events{
                id
            }
        }
      }
      `,
    }),
  });

  const pageData = await foundPageData.json();

  return pageData;
}
const iframe = document.createElement("iframe");
getPage().then((data) => {
  iframe.src = data.data.page.url;
});
// iframe style
iframe.style.width = "700px";
iframe.style.height = "550px";
iframe.style.position = "absolute";
iframe.style.top = "50%";
iframe.style.left = "50%";
iframe.style.transform = "translate(-50%, -50%)";
iframe.style.zIndex = "1000";
iframe.style.opacity = "0.5";
iframe.id = "myIframe";

// const newIframe = document.getElementById("myIframe");
iframe.addEventListener("load", (ev) => {
  const new_style_element = document.createElement("style");
  new_style_element.textContent = ".my-class { display: none; }";
  ev.target.contentDocument.head.appendChild(new_style_element);
});

// webkit style

const body = document.getElementById("heatmapContainer");
body.appendChild(iframe);

var canvas = document.getElementById("myCanvas");

var ctx = canvas.getContext("2d");
ctx.canvas.willReadFrequently = true;

// create configuration object
var config = {
  container: document.getElementById("heatmapContainer"),
  radius: 10,
  maxOpacity: 0.5,
  minOpacity: 0,
  blur: 0.75,
};

// canvas style end
var ctx = canvas.getContext("2d");
ctx.canvas.willReadFrequently = true;

// canvas width and height should be the width and height of length of the page inside the iframe
canvas.width = "700px";
canvas.height = "550px";

// create configuration object
var config = {
  container: document.getElementById("heatmapContainer"),
  radius: 10,
  maxOpacity: 0.3,
  minOpacity: 0,
  blur: 0.75,
};

// multiple datapoints (for data initialization use setData!!)
var dataPoints = [
  { x: 50, y: 50, value: 50 },
  { x: 100, y: 100, value: 70 },
  { x: 150, y: 150, value: 46 },
  { x: 200, y: 200, value: 100 },
  { x: 250, y: 250, value: 100 },
  { x: 250, y: 250, value: 100 },
  { x: 350, y: 350, value: 100 },
  { x: 250, y: 550, value: 100 },
  { x: 550, y: 250, value: 100 },
  { x: 100, y: 200, value: 100 },
  { x: 250, y: 250, value: 100 },
  { x: 280, y: 200, value: 100 },
  { x: 350, y: 650, value: 100 },
  { x: 350, y: 650, value: 100 },
  { x: 350, y: 650, value: 100 },
  { x: 350, y: 650, value: 100 },
  { x: 500, y: 250, value: 100 },
  { x: 500, y: 250, value: 100 },
  { x: 700, y: 750, value: 100 },
];

// create heatmap with configuration
var heatmapInstance = h337.create(config);
heatmapInstance.addData(dataPoints);
