import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const resolvers = {
  Query: {
    allEvents: (parent, args, context) => {
      return prisma.event.findMany({
        include: {
          page: true,
        },
      });
    },
    event: (parent, { id }, context) => {
      return prisma.event.findUnique({
        where: { id },
        include: {
          page: true,
        },
      });
    },
    allPages: (parent, args, context) => {
      return prisma.page.findMany({
        include: {
          events: true,
        },
      });
    },
    page: (parent, { id }, context) => {
      return prisma.page.findUnique({
        where: { id },
        include: {
          events: true,
        },
      });
    },
  },
  Mutation: {
    createEvent: async (
      parent,
      { sessionId, pageId, trackedData },
      context
    ) => {
      const stringifiedData = JSON.stringify(trackedData);

      const createEvent = await prisma.event.create({
        data: {
          sessionId,
          pageId,
          trackedData: stringifiedData,
          type: "click",
        },
      });

      return createEvent;
    },
    createPage: async (parent, { url, title, doc }, context) => {
      const createEvent = await prisma.page.create({
        data: {
          url,
          title,
          doc,
        },
      });

      return createEvent;
    },
  },
};

export default resolvers;
