const typeDefs = `#
scalar Json
scalar DateTime


type Event {
    id: String!
    sessionId: String!
    pageId: String!
    trackedData: Json!
    createdAt: DateTime!
    page: Page
    type: String!
  }
  
  type Page {
    id: String!
    url: String!
    title: String!
    doc: Json!
    createdAt: DateTime!
    events: [Event]
  }

type Query {
  allEvents: [Event!]!
  event(id: String!): Event
  allPages: [Page!]!
  page(id: String!): Page
}

type Mutation {
  createEvent(sessionId: String!, pageId: String!, trackedData: Json!): Event!
  createPage(url: String!, title: String!, doc: Json!): Page!
}










  
 
`;
export default typeDefs;
